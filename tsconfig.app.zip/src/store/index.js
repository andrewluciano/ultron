import { createStore, compose, applyMiddleware } from 'redux';
import { persistStore, persistReducer } from 'redux-persist';


const persistConfig = {
  key: 'root',
  whitelist: [],
};

const persistedReducer = persistReducer(
  persistConfig
);

function configureStore(preloadedState) {
  const store = createStore(persistedReducer, preloadedState, enhancer);
  return store;
}

const store = configureStore();
const persistor = persistStore(store);

sagaMiddleware.run(indexSaga);

export { store, persistor };