import {styled} from 'stitches.config';


export const Container = styled('div',{
    display:'flex',
    alignItems:'flex-start',
    flexDirection:'column',
    boxSizing:'border-box',
    padding:'24px 0px',    
    color: '$bgGrayTransparent50',
    width:'100%',
    height:'66px',
})