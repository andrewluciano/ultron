import { } from 'react';
import { Container } from './Styles';
export const BreadCrumb = () => {

    return (
      <Container>
        BreadCrumb
      </Container>      
    );
  };