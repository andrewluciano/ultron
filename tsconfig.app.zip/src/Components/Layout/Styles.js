import {styled} from 'stitches.config';

export const MainLayout = styled('div',{
    display:'flex',
    backgroundColor:'#f4f4f4',
    width:'100vw',
    height:'100vh',
    fontFamily:'Mulish, sans-serif',
    
})

export const AreaDireita = styled('div',{
    display:'flex',
    flexDirection: 'column',
    width: '100%'
})

export const AreaRolagem = styled('div',{
    display:'flex',
    overflowX:'auto',
    flexDirection: 'column',
    width: '100%',
    backgroundImage:'$white',
})