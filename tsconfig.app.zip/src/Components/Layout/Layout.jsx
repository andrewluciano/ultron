import PropTypes from 'prop-types';
import {SideBarMenu} from 'Components/SideBarMenu';
import {Header} from 'Components/Header';
import {MainLayout, AreaDireita,AreaRolagem} from './Styles'

  
const Layout = ({children}) => {
    return (
        <MainLayout>
            <SideBarMenu />
            <AreaDireita>
                <Header />
                <AreaRolagem>
                    {children}
                </AreaRolagem>
            </AreaDireita>
        </MainLayout>
    )
}

Layout.propTypes = {
    children: PropTypes.any,
}

export default Layout;