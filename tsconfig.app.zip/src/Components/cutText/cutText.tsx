import { Tooltip } from 'react-tooltip'
import { } from 'react';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const CutText = (props: any) => {
    const contagem = props.contagem || 20;
    const position = props.position || 'right';
    const pontos = props.value.length > contagem ? '...' : '';
    return (
      <>
        <Tooltip id="inicial" style={{'maxWidth':"400px"}} data-tooltip-place={position}/>
        <p data-tooltip-id='inicial' data-tooltip-content={props.value} title={props.value}>{props.value.substring(0, contagem) + pontos}</p>
      </>
      
    );
  };