import styled from 'styled-components';

export const paragrafo = styled.p`
  border: 1px solid red !important;
`;