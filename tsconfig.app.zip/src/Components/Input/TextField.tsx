import {type FC} from 'react';

import TextField from '@mui/material/TextField';

const TextFieldCustom: FC = () => {
    return (
     <>   
     <TextField
        id="filled-helperText"
        label="Helper text"
        defaultValue="Default Value"
        helperText="Some important text"
        variant="filled"
        />
      </>
    )
}

export default TextFieldCustom;