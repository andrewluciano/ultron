import {styled} from 'stitches.config';
// import pesquisa from 'assets/icons/pesquisa.svg'
import pesquisa from 'assets/icons/pesquisa.svg?react';


export const Container = styled('div',{
    position:'relative',
    display:'flex',
    boxSizing:'border-box',
    padding:'10px',
    alignItems:'center',
    // backgroundColor:'$white',
    // color: 'rgba(135, 139, 143, 1)',
    width:'50px',
    height:'40px',
    borderRadius:'50px',    
    transition:'all 0.2s ease-in-out 0s',

    variants:{
        trigger:{
            true:{
                width:'90%',
                backgroundColor:'$white',
            },
            false:{
                backgroundColor:'transparent',
            }
        }
    }
})

export const InputCustom = styled('input',{
    fontFamily:'Mulish, sans-serif',
    background:'none',
    border:'none',
    boxSizing:'border-box',
    padding:'0 10px',
    width:'90%',
    '&:focus':{
        border:'none'
    },
    '&:active':{
        border:'none'
    }
})

export const OpenSearch  = styled(pesquisa,{
    position:'absolute',
    right:'10px',
    display:'flex',
    boxSizing:'border-box',
    padding:'5px',
    width:'30px',
    height:'30px',
    cursor:'pointer',
    variants:{
        trigger:{
            true:{
                path : {
                    fill:'$ColorB3NeutralBlack100',
                },
                
            },
            false:{}
        }
    }
})



export const ContainerFiltros = styled('div',{
    position:'absolute',
    backgroundColor:"$white",
    boxShadow:'0px 10px 5px rgba(0,0,0,0.1)',
    borderRadius:'0 0 4px 4px',
    width:'80%',
    height:'300px',
    bottom:'0',
    transform:'translate(0%,100%)',
    display:'flex',
    flexDirection:'row',

})


export const AreaSugestao = styled('div',{
    display:'flex',
    boxSizing:'border-box',
    padding:'10px',
    flex:'2',
    color:'#333',
    
})
export const Filtros = styled('div',{
    display:'flex',
    boxSizing:'border-box',
    padding:'10px',
    flex:'1',
    color:'#333',
    
    borderLeft:'1px solid rgba(0, 0, 0, 0.27)'
})

