import { Tooltip } from 'react-tooltip'
import { type FC, useState } from 'react';
import { Container,InputCustom,OpenSearch,ContainerFiltros,AreaSugestao, Filtros } from './Styles';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const ItemPesquisa:FC = (props: any) => {
  const [openSearch,setOpenSearch] = useState(false);
  return (
    <Container trigger={openSearch}>
      {openSearch && 
        <InputCustom type="text" placeholder="Buscar..." />
      }
      <OpenSearch trigger={openSearch} onClick={()=>{setOpenSearch(!openSearch)}}/>
      {openSearch && 
        <ContainerFiltros>
          <AreaSugestao>
            <h4>Sugestão:</h4>
          </AreaSugestao>
          <Filtros>
            <h4>Filtrar:</h4>
          </Filtros>
        </ContainerFiltros>
      }
    </Container>
  );
};