import {styled} from 'stitches.config';

export const Container = styled('div',{
    display:'flex',
    boxSizing:'border-box',
    alignItems:'center',
    backgroundColor:'rgba(30, 32, 35, 1)',
    color: 'rgba(255, 255, 255, 0.87)',
    width:'100%',
    height:'70px'
})


export const AreaPesquisa = styled('div',{
    display:'flex',
    boxSizing:'border-box',
    padding:'0 20px 0 0',
    justifyContent:'flex-end',
    flex:'3',
})
export const AreaLinks = styled('div',{
    display:'none',
    gap:'20px',
    flex:'3',
})
export const AreaPerfil = styled('div',{ 
    position:'relative',
    boxSizing:'border-box',
    padding:'0 20px',
    maxWidth:'190px',
    flex:'1',
    '&:after':{
        position:'absolute',
        content:'',
        display:'block',
        width:'1px',
        height:'50%',
        left:'0px',
        top:'50%',
        backgroundColor:'rgba(255, 255, 255, 0.2)',
        transform:'translateY(-50%)',
    }
})

export const ItemLinks = styled('a',{
    display:'flex',
    gap:'10px',   
    color:'$white',
    fontSize:'1rem',
    fontWeight:'500',
    textDecoration:'none'
    
})