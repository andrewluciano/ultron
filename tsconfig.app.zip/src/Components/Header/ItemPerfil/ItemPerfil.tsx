import { Tooltip } from 'react-tooltip'
import { type FC, useState } from 'react';
import { Container } from './Styles';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const ItemPerfil:FC = (props: any) => {
  const [openSearch,setOpenSearch] = useState(false);
  return (
    <Container>
      <p>Antonio Carlos</p>
    </Container>
  );
};