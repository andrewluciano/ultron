import {styled} from 'stitches.config';

export const Container = styled('div',{
    position:'relative',
    display:'flex',
    boxSizing:'border-box',
    alignItems:'center',

    color: 'rgba(255, 255, 255, 0.87)',
    width:'100%',
    height:'70px'
})

