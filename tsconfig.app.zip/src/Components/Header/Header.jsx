import React from 'react';
import { Container,AreaPesquisa,AreaPerfil,ItemLinks } from './Styles';
import {ItemPerfil} from './ItemPerfil/ItemPerfil'
import {ItemPesquisa} from './ItemPesquisa/ItemPesquisa'

import { Tipi } from '@phosphor-icons/react';

export const Header = ({open,closeMenu}) => {
    return (
        <Container>
            <AreaPesquisa>
                <ItemPesquisa />
            </AreaPesquisa>
            <AreaPerfil>
                <ItemPerfil />
            </AreaPerfil>
            
        </Container>
    )
}


