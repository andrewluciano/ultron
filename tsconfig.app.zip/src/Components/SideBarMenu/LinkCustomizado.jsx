import React from 'react';
import {LinkCustom} from './Styles'

export const LinkCustomizado = ({link,nome,icone,tipo,label}) => {
    const iconeCompleto = ('/src/assets/icons/'+icone+'.svg');
    
    return (
        <>
        {label ? (
            <LinkCustom data-tooltip-id="tooltip" data-tooltip-content={label} data-tooltip-place="right" tipo={tipo} to={link}>{icone}<span>{nome}</span></LinkCustom>
        ):(
            <LinkCustom tipo={tipo} to={link}>{icone}<span>{nome}</span></LinkCustom>
        )}
            
        </>
    )
}

