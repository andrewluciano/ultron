import React from 'react';
import logoB3Menu from 'assets/images/logo-b3-menu.svg';
import {LinkCustomizado} from './LinkCustomizado'
import { Container, Menu } from './Styles';
import ImgDashboard from 'assets/icons/home.svg';
import imgMosaico from 'assets/icons/mosaico.svg';
import imgMinimizar from 'assets/icons/minimizar.svg';

export const SideBarMenu = ({open,closeMenu}) => {
    const imgRender = (icone) => {
        return <img src={icone} />
    }
    return (
        <Container>            
            <Menu>
                <LinkCustomizado link='/' icone={<img src={logoB3Menu} width={'30px'} height={'30px'} />} />
                <LinkCustomizado label="Dashboard" nome="Dashboard" link="/dashboard" icone={imgRender(ImgDashboard)}  />
                <LinkCustomizado label="Manuais" nome="Manual" link="/dashboard" icone={imgRender(imgMosaico)}  />
                <LinkCustomizado label="Minimizar" nome="Minimizar" link="/dashboard" icone={imgRender(imgMinimizar)} tipo="fechar"  />
            </Menu>
        </Container>
    )
}


