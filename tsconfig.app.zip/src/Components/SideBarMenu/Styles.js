import {styled} from 'stitches.config';
import { Link } from 'react-router-dom';

export const Container = styled('div',{
    display:'flex',
    flexDirection:'column',
    backgroundColor:'rgba(30, 32, 35, 1)',
    color: 'rgba(255, 255, 255, 0.87)',
    width:'70px',
    height:'100vh',
    boxShadow:'0px 10px 10px rgba(0,0,0,0.1)'
})

export const LinkCustom = styled(Link,{
    display:'flex',
    alignItems:'center',
    justifyContent:'center',
    width:'70px',
    height:'70px',
    color:'#fff',
    textDecoration:'none',
    span:{
        display:'none'
    },
    variants:{
        tipo:{
            default:{

            },
            fechar:{
                position:'absolute',
                bottom:'0px',
                backgroundColor:'$YellowPrimary',
                height:'48px'
            }
        }
    }
})

export const Menu = styled('menu',{
    position:'relative',
    display:'flex',
    height:'100%',
    flexDirection:'column',

})
export const subMenu = styled('menu',{
    position:'relative',
    display:'none',
    height:'100%',
    flexDirection:'column',

})