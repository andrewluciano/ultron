import {styled} from 'stitches.config';


export const Container = styled('div',{
    display:'flex',
    flexDirection:'column',
    gap:'12px',
    boxSizing:'border-box',
    alignItems:'center',
    justifyContent:'center',
    backgroundColor:'$ColorPrimary',
    color:'$white',
    fontFamily:'Mulish, sans-serif',    
    width:'100vw',
    height:'100vh',
    p:{
        margin:'0px',
        padding:'0px',
        fontSize:'$15'
    }
})

export const H4 = styled('h4',{
    fontSize:'$36',
    fontWeight:'300',
    margin:'0px',
    padding:'0px',
    textTransform:'uppercase'
})
export const Button = styled('a',{
    fontSize:'$12',
    letterSpacing:'1.5px',
    textDecoration:'none',
    borderRadius:'100px',
    fontWeight:'700',
    margin:'0px',
    padding:'10px 40px',
    textTransform:'uppercase',
    backgroundColor:'$YellowPrimary',
    color:"$ColorPrimary",
    '&:hover':{
        backgroundColor:'$LightYellow'
    }
})