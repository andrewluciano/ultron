import { type FC } from 'react';
import { Container, H4, Button } from './Styles';
import imgLogoB3 from 'assets/images/logo-b3-menu.svg';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const PaginaLogin:FC = () => {
//   const [openSearch,setOpenSearch] = useState(false);
  return (
    <Container>
      <img src={imgLogoB3} width={'88px'} height={'77px'} />
      <H4>Ultron</H4>
      <p>
        Entre com seus dados através do <br /> e-mail para acessar a ferramenta
      </p>
      <Button href="/dashboard">Entrar</Button>
    </Container>
  );
};

export default PaginaLogin;