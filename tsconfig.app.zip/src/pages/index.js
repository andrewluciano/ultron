import PaginaRotas from "./PaginaRotas";
import PaginaHome from "./PaginaHome";
export {
    PaginaRotas,
    PaginaHome
}