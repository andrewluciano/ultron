import React from 'react';
import {Router,Route} from 'react-router';
import {PaginaHome} from 'pages';
import Layout from 'Components/Layout';

const PaginaRotas = () => {

    return (
            <Router history={undefined}>
                <Layout>
                    <Route path="/dashboard" element={<PaginaHome />} />
                </Layout>
            </Router>
        
    )

}

export default PaginaRotas;