import {styled} from 'stitches.config';


export const Container = styled('div',{
    display:'flex',
    flexDirection:'column',
    boxSizing:'border-box',
    padding:'10px 48px',
    alignItems:'flex-start',
    fontFamily:'Mulish, sans-serif',    
})
