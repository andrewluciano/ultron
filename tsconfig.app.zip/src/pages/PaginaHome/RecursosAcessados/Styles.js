import {styled} from 'stitches.config';


export const Container = styled('div',{
    display:'flex',
    width:'100%',
    flexDirection:'column',
    boxSizing:'border-box',
    padding:'24px 0px',
    justifyContent:'flex-start',
    alignItems:'flex-start',
    fontFamily:'Mulish, sans-serif',    

})


export const TitleRecursos = styled('h2',{
    fontSize:'$30',
    fontWeight:'300',
    padding:'0px',
    margin:'0',
    height:'40px',
    width:'100%',
    borderBottom:'1px solid #ccc',
    textAlign:'left',
    
})

export const AreaTags = styled('div',{
    display:'flex',
    padding:'24px 10px',
    margin:'0',
    boxSizing:'border-box',
    height:'auto',
    width:'100%',
    gap:'12px'

})

export const Tag = styled('a',{
    display:'flex',
    justifyContent:'center',
    alignItems:'center',
    textTransform:'uppercase',
    border:'1px solid $BluePrimary',
    color:'$BluePrimary',
    fontSize:'$10',
    boxSizing:'border-box',
    padding:'3px 20px',
    borderRadius:'50px',
    fontWeight:'700',
    letterSpacing:'1.5px',
    '&:hover':{
        backgroundColor:'$LightYellow',
        border:'1px solid $LightYellow',
        color:'$ColorPrimary',
    },
    variants:{
        ativo:{
            true:{
                backgroundColor:'$LightYellow',
                border:'1px solid $LightYellow',
                color:'$ColorPrimary',
            }
        }
    }
})

export const AreaRecursos = styled('div',{
    display:'flex',
    flexWrap:'wrap',
    width:'100%',
    flexDirection:'row',
    gap:'24px',
    boxSizing:'border-box',
    padding:'24px 0px',
    justifyContent:'flex-start',
    alignItems:'flex-start',
    fontFamily:'Mulish, sans-serif',
})