import {styled} from 'stitches.config';
import ArrowRight from 'assets/icons/ArrowRight.svg';


export const Container = styled('div',{
    display:'flex',
    width:'100%',
    flexDirection:'column',
    boxSizing:'border-box',
    padding:'0px',
    maxWidth:'348px',
    justifyContent:'flex-start',
    alignItems:'flex-start',
    fontFamily:'Mulish, sans-serif',
    backgroundColor:'$white',
    boxSizing:'border-box',
    borderRadius:'8px',
    boxShadow:'0px 8px 16px rgba(0,0,0,0.1)',
    h3:{
        boxSizing:'border-box',
        fontSize:'$20',
        fontWeight:'600',
        padding:'24px',
        width:'100%',
        textAlign:'left',
        borderRadius:'8px 8px 0 0 ',
        color:'rgba(102, 110, 122, 1)',
        textTransform:'uppercase',
        backgroundColor:'rgba(102, 110, 122, 0.1)',
    },
    h4:{
        boxSizing:'border-box',
        fontSize:'$20',
        padding:'24px 24px 0 24px',
        width:'100%',
        textAlign:'left',
        fontWeight:'600'
    },
    p:{
        padding:'24px',
        boxSizing:'border-box',
        color:'rgba(102, 110, 122, 1)',
        textAlign:'left',
    },
    a:{
        position:'relative',
        display:'flex',
        flexDirection:'row',
        fontSize:'$14',
        padding:'0 24px 24px 24px',
        boxSizing:'border-box',
        textAlign:'left',
        color:'$BluePrimary',
        fontWeight:'500',
        '&:after':{
            position:'absolute',
            content:'',
            display:'block',
            width:'16px',
            height:'16px',
            backgroundImage:`url(${ArrowRight})`,
            right: '0px',
            top:'0px',
            filter: 'invert(75%)'
        },


    }
})
