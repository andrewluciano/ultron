import { type FC } from 'react';
import { Container } from './Styles';


interface IMyProps {
    titulo:string;
    subTitulo:string;
    texto:string;
    link:string;
}

export const Recursos: FC<IMyProps> = (props: IMyProps) => {
    return (
        <Container>
            <h3>{props.titulo}</h3>
            <h4>Lorem Ipsum - Sub-título (2 linhas máximo)</h4>
            <p>Lorem ipsum dolor sit amet consectetur. Maecenas pretium est et nec. Etiam in lacus ac id in pellentesque mauris diam sit. Est adipiscing interdum aliquet gravida a nisl pulvinar eget quis. (5 linhas máximos)</p>
            <a href="javascript:void(0);">Acesse aqui</a>
        </Container>
    )
}

