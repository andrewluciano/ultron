import { type FC } from 'react';
import { Container,TitleRecursos,AreaTags ,AreaRecursos,Tag} from './Styles';
import { Recursos } from './Recursos';



export const RecursosAcessados: FC = () => {
    return (
        <Container>
            <TitleRecursos>Recursos mais acessados</TitleRecursos>
            <AreaTags>
                <Tag ativo={true}>Todos</Tag>
                <Tag>Repositórios</Tag>
                <Tag>Documentação</Tag>
                <Tag>Paths</Tag>
            </AreaTags>
            <AreaRecursos>
                <Recursos titulo="Serviços - MicrosServiço" subTitulo={''} texto={''} link={''} />
                <Recursos titulo="Serviços - MicrosServiço" subTitulo={''} texto={''} link={''}  />
                <Recursos titulo="Serviços - MicrosServiço" subTitulo={''} texto={''} link={''}  />
                <Recursos titulo="Serviços - MicrosServiço" subTitulo={''} texto={''} link={''}  />
                <Recursos titulo="Serviços - MicrosServiço" subTitulo={''} texto={''} link={''}  />
                <Recursos titulo="Serviços - MicrosServiço" subTitulo={''} texto={''} link={''}  />
            </AreaRecursos>
        </Container>
    )
}

