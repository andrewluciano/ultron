import {styled} from 'stitches.config';


export const Container = styled('div',{
    display:'flex',
    flexDirection:'row',
    margin:'24px 0px 0px 0px',
    gap:'12px',
    boxSizing:'border-box',
    alignItems:'flex-start',
    justifyContent:'flex-start',
    color:'$ColorPrimary',
    fontFamily:'Mulish, sans-serif',    
    width:'100%',
    height:'390px',
    padding:'16px',
})

export const BlocoFavoritos = styled('div',{
    display:'flex',
    flexDirection:'column',
    gap:'12px',
    boxSizing:'border-box',
    alignItems:'flex-start',
    justifyContent:'flex-start',
    color:'$ColorPrimary',
    fontFamily:'Mulish, sans-serif',    
    width:'50%',
    height:'100%',
    padding:'24px',
    backgroundColor:'$white',
    borderRadius:'8px',
    boxShadow:'0p 8px 16px rgba(0,0,0,0.1)',
})
export const BlocoVisitados = styled('div',{
    display:'flex',
    flexDirection:'column',
    gap:'12px',
    boxSizing:'border-box',
    alignItems:'flex-start',
    justifyContent:'flex-start',
    color:'$ColorPrimary',
    fontFamily:'Mulish, sans-serif',    
    width:'50%',
    height:'100%',
    padding:'24px',
    backgroundColor:'$white',
    borderRadius:'8px',
    boxShadow:'0p 8px 16px rgba(0,0,0,0.1)',
})

export const AreaTitulo = styled('div',{
    display:'flex',
    flexDirection:'row',
    width:'100%',
    alignItems:'center',
    h4:{
        textAlign:'left',
        flex:'4',
        color:'$TextColorDestaque',
        fontSize:'$18',
        fontWeight:'700'
    },
    input:{

    }
})
export const AreaLista = styled('div',{
    padding:'0',
    margin:'0',
    width:'100%',
    height:'100%',
    overflowY:'auto',


})
export const Lista = styled('ul',{
    padding:'0',
    margin:'0',
    width:'99%',
    height:'100%',
    listStyle:'none',
    li:{
        cursor:'pointer',
        display:'flex',
        '&:nth-of-type(2n+1)':{
            backgroundColor:'$nwSlate200'
        }, 
        padding:'12px 10px',
        margin:'0',
        boxSizing:'border-box',
        TextAlign:'left',
        p:{
            display:'flex',
            flex:'7',
            TextAlign:'left',
            color:'$BluePrimary',
        },
        svg:{
            flex:'1'
        }
    }

    
})
