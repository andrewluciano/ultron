import { type FC } from 'react';
import { Container,BlocoFavoritos,AreaTitulo,AreaLista,Lista, BlocoVisitados } from './Styles';
import { Star,MagnifyingGlass } from '@phosphor-icons/react';
import { CutText } from 'Components/cutText/cutText';
import InputAdornment from '@mui/material/InputAdornment';
import TextField from '@mui/material/TextField';


export const Favoritos: FC = () => {


    return (
        <Container>
            <BlocoFavoritos>
                <AreaTitulo>
                    <h4>Favoritos</h4>

                    <TextField
                        id="input-with-icon-textfield"
                        placeholder="Pesquisar"
                        slotProps={{
                            
                        input: {
                            startAdornment: (
                            <InputAdornment position="start">
                                <MagnifyingGlass width={'20px'} height={'20px'} />
                            </InputAdornment>
                            ),
                        },
                        }}
                        variant="standard"
                    />                                        
                </AreaTitulo>
                <AreaLista>
                    <Lista>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>
                                <CutText contagem={40} value={'Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet'} />
                            </p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                        <li>
                            <p>Lorem ipsum dolor sit amet</p>
                            <Star />
                        </li>
                    </Lista>
                </AreaLista>
            </BlocoFavoritos>
            <BlocoVisitados>
                <AreaTitulo>
                    <h4>Favoritos</h4>
                    <TextField
                        id="input-with-icon-textfield"
                        placeholder="Pesquisar"
                        slotProps={{
                            
                        input: {
                            startAdornment: (
                            <InputAdornment position="start">
                                <MagnifyingGlass width={'20px'} height={'20px'} />
                            </InputAdornment>
                            ),
                        },
                        }}
                        variant="standard"
                    />       
                </AreaTitulo>
                <AreaLista>
                    <Lista>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                        <li><p>Lorem ipsum dolor sit amet</p></li>
                    </Lista>
                </AreaLista>
            </BlocoVisitados>            
        </Container>
    )
}

