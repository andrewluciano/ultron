import { type FC } from 'react';
import { Container, TypesItems } from './Styles';



export const TypesPaths: FC = () => {

    return (
        <Container>
            <TypesItems>
                <h3>
                    Golder Paths
                </h3>
                <p>
                    Componentes que realizam deploy até produção e são mantidos pelo time Ultron
                </p>
                <a href="javascript:void(0);">Buscar componente</a>
            </TypesItems>
            <TypesItems>
                <h3>
                    Silver Paths
                </h3>
                <p>
                    Componentes em pré-produção que podem exigir procedimentos manuais ou da equipe
                </p>
                <a href="javascript:void(0);">Buscar componente</a>
            </TypesItems>
            <TypesItems>
                <h3>
                    Experimentais
                </h3>
                <p>
                    Componentes experimentais criados pela comunidade podem ser encontrados nesta sessão
                </p>
                <a href="javascript:void(0);">Buscar componente</a>
            </TypesItems>
        </Container>
    )
}

