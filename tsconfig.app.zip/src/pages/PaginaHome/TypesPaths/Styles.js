import {styled} from 'stitches.config';
import ArrowRight from 'assets/icons/ArrowRight.svg';
import bgPathys from 'assets/images/backgrounds/bgPaths.jpg';

export const Container = styled('div',{
    display:'flex',
    flexDirection:'row',
    gap:'24px',
    boxSizing:'border-box',
    alignItems:'center',
    justifyContent:'center',
    color:'$white',
    fontFamily:'Mulish, sans-serif',    
    width:'100%',
    height:'196px',
})
export const TypesItems = styled('div',{
    position:'relative',
    display:'flex',
    flexDirection:'column',
    backgroundSize:'cover',
    gap:'24px',
    backgroundRepeat:'no-repeat',
    maxWidth:'385px',
    height:'196px',
    boxSizing:'border-box',
    padding:'24px',
    borderRadius:'8px',
    textAlign:'left',
    backgroundColor:'$ColorPrimary',
    '&:before':{
        position:'absolute',
        zIndex:'0',
        top:'0px',
        left:'0px',
        content:'',
        display:'block',
        backgroundImage:`url(${bgPathys})`,
        backgroundRepeat:'no-repeat',
        backgroundSize:'cover',
        borderRadius:'8px',
        filter:'grayscale(1) contrast(0.8)',
        width:'100%',
        height:'100%',

    },
    h3:{
        zIndex:'7',
        fontSize:'$24'
    },
    p:{
        zIndex:'2',
        height:'50px',
    },
    a:{
        display:'flex',
        alignItems:'center',
        position:'relative',
        color:"$LightYellow",
        fontWeight:'500',

        fontSize:'$14',
        '&:after':{
            position:'relatve',
            content:'',
            display:'block',
            width:'16px',
            height:'16px',
            backgroundImage:`url(${ArrowRight})`,
            marginLeft:'5px',
            top:'0px'
        }
    }
})

