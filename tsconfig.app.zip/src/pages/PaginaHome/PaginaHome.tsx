import { type FC } from 'react';

import {PrincipaisRecursos} from './PrincipaisRecursos';
import {Favoritos} from './Favoritos';
import {TypesPaths} from './TypesPaths';
import {RecursosAcessados} from './RecursosAcessados';

import { Container } from './Styles';
import { TitlePage } from '../Styles';
import { BreadCrumb } from 'Components/BreadCrumb';

const PaginaHome: FC = () => {
    return (
        <Container>
            <BreadCrumb />
            <TitlePage>Boas vindas ao ULTRON, Gabriel Nunes</TitlePage>

            <PrincipaisRecursos />
            <Favoritos />
            <TypesPaths />
            <RecursosAcessados />
            
            
        </Container>
    )
}

export default PaginaHome;