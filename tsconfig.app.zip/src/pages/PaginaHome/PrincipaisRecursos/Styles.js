import {styled} from 'stitches.config';


export const Container = styled('div',{
    display:'flex',
    flexDirection:'column',
    gap:'12px',
    boxSizing:'border-box',
    alignItems:'flex-start',
    justifyContent:'flex-start',
    backgroundColor:'$bgGray',
    color:'$white',
    fontFamily:'Mulish, sans-serif',    
    width:'100%',
    height:'540px',
    borderRadius:'8px',
    padding:'36px 48px',
    '.teste':{
        overflow:'hidden',
        width:'100%',
        border:'1px solid blue',
        margin:'0',
        padding:'0'
    },
    '.image-item':{
        border:'1px solid yellow'
    }

})


export const Title = styled('h3',{
    display:'flex',
    boxSizing:'border-box',
    padding:'12px 0px',
    fontSize: '$28',
    margin:'0',
    fontWeight: '700',
    color:'$gray700'
    
})

export const AreaDestaques = styled('div',{
    display:'flex',
    flexDirection:'row',
    gap:'12px',
    border:'2px solid blue',
    // overflow:'hidden',
    width:'100%'
});

export const Destaque = styled('div',{
    // width:'300px',
    // height:'356px',
    borderRadius:'8px',
    backgroundColor:'$white',
    color:'$ColorPrimary',
    border:'1px solid red',
    boxShadow:'0px 3px 3px rgba(102, 110, 122, 0.1)',
    img:{
        backgroundColor:'$nwViolet700',
        height:'45%',
        width:'100%'
    }
});

export const AreaTexto = styled('div',{
    boxSizing:'border-box',
    padding:'12px 0px',
});
