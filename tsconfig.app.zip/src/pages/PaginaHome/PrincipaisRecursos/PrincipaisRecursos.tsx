import { type FC } from 'react';
import { Container,Title, AreaDestaques, Destaque,AreaTexto } from './Styles';
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

export const PrincipaisRecursos: FC = () => {
    const responsive = {
        desktop: {
          breakpoint: { max: 300, min: 300 },
          items: 4,
          slidesToSlide: 3 // optional, default to 1.
        },
        tablet: {
          breakpoint: { max: 1024, min: 464 },
          items: 2,
          slidesToSlide: 2 // optional, default to 1.
        },
        mobile: {
          breakpoint: { max: 464, min: 0 },
          items: 1,
          slidesToSlide: 1 // optional, default to 1.
        }
      };

    return (
        <Container>
            <Title>Conheça os principais recursos do ULTRON:</Title>
            <AreaDestaques>
            <Carousel
            // className='teste'
                swipeable={true}
                draggable={true}
                showDots={true}
                responsive={responsive}
                ssr={true} // means to render carousel on server-side.
                infinite={true}
                autoPlay={true}
                itemClass="image-item"
                autoPlaySpeed={100}
                keyBoardControl={false}
                customTransition="all .5"
                transitionDuration={200}
                deviceType={'desktop'}
            >
                <Destaque>
                    <img />
                    <AreaTexto>
                        <h5>O que é o Ultron?</h5>
                        <p>(Sobre) Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a>link</a>
                    </AreaTexto>
                </Destaque>
                <Destaque>
                    <img />
                    <AreaTexto>
                        <h5>O que é o Ultron?</h5>
                        <p>(Sobre) Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a>link</a>
                    </AreaTexto>                    
                </Destaque>
                <Destaque>
                    <img />
                    <AreaTexto>
                        <h5>O que é o Ultron?</h5>
                        <p>(Sobre) Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a>link</a>
                    </AreaTexto>                    
                </Destaque>
                <Destaque>
                    <img />
                    <AreaTexto>
                        <h5>O que é o Ultron?</h5>
                        <p>(Sobre) Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a>link</a>
                    </AreaTexto>                    
                </Destaque>
                <Destaque>
                    <img />
                    <AreaTexto>
                        <h5>O que é o Ultron?</h5>
                        <p>(Sobre) Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a>link</a>
                    </AreaTexto>                    
                </Destaque>
                <Destaque>
                    <img />
                    <AreaTexto>
                        <h5>O que é o Ultron?</h5>
                        <p>(Sobre) Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a>link</a>
                    </AreaTexto>                    
                </Destaque>

            </Carousel>

            </AreaDestaques>
        </Container>
    )
}

