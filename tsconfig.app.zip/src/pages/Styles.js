import {styled} from 'stitches.config';


export const TitlePage = styled('h2',{
    fontSize:'$36',
    fontWeight:'300',
    boxSizing:'border-box',
    padding:'12px 0',
    color:'rgba(64, 68, 77, 1)',
    'strong':{
        fontWeight:'700'
    }
})