// import { useState } from 'react';
import {} from 'react';
import {globalStyles} from 'stitches.config';

import {Routes,Route,Outlet} from 'react-router-dom';
// import { Provider } from 'react-redux'
import { QueryClientProvider } from 'react-query';
// import { store } from 'store';
import Layout from 'Components/Layout';
import { Tooltip } from 'react-tooltip'

import  PaginaHome  from 'pages/PaginaHome';
import  PaginaLogin  from 'pages/PaginaLogin';

import './App.css'
import { queryClient } from 'helpers/queryClient';

function App() {
  // const [count, setCount] = useState(0)
  globalStyles();

  return (
      
        <QueryClientProvider client={queryClient}>
          <Tooltip  id="tooltip" />
          <Routes>
            <Route path="/login" element={<PaginaLogin />} />
            <Route  element={
              <Layout>
                <Outlet />
              </Layout>
            }>
            <Route path="/dashboard" element={<PaginaHome />} />
                

            </Route> 
          </Routes>
        </QueryClientProvider>
      
  )
}

export default App
